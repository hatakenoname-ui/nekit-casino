# Nekit Casino — Enhanced Prototype

This enhanced prototype includes:
- SQLite persistence (db/casino.db)
- Slot game with commit-reveal fairness (serverSeed stored; use /api/reveal/:roundId to verify)
- Dice game
- Per-user balance stored in DB
- Admin API to view recent rounds (use ADMIN_PASSWORD)
- Telegram WebApp-compatible UI (reads Telegram.WebApp.initDataUnsafe.user.id)
- Ready to deploy to Railway (ZIP)

## Files
- server.js — backend + Telegram bot
- webapp/index.html — web UI
- webapp/assets/style.css — styles
- admin/index.html — simple admin page
- db/ — contains SQLite DB (created at runtime)
- .env.example — environment variables

## Deploy to Railway
1. Create project on Railway -> "Deploy from ZIP"
2. Upload this ZIP.
3. Set environment variables in Railway:
   - BOT_TOKEN (required)
   - ADMIN_PASSWORD (set a secret)
   - WEBAPP_BASE_URL (your Railway URL, e.g. https://yourapp.up.railway.app)
4. Deploy. Bot will start automatically.
5. In BotFather, set the Web App URL to `https://yourapp.up.railway.app/index.html` for your bot so users can open the Web App.

## Notes & Limitations
- This is a **prototype** for testing using playmoney. Do NOT use for real-money gambling without legal compliance and security hardening.
- SQLite on Railway may be ephemeral depending on the deployment tier. For production use Postgres or other persistent DB.
- The admin endpoint is protected only by a simple password (ADMIN_PASSWORD). For production use stronger auth.

## How to verify fairness (slot)
After a slot spin you'll get `roundId` and `serverSeedHash` in response. To reveal and verify, call:
`/api/reveal/:roundId` — it returns the serverSeed and reels so you can recompute RNG:
HMAC(serverSeed, clientSeed + ':' + counter) -> reproduce reels.

