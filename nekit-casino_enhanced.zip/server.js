const express = require('express');
const { Telegraf } = require('telegraf');
const path = require('path');
const crypto = require('crypto');
const sqlite3 = require('sqlite3').verbose();
const bodyParser = require('body-parser');

const app = express();
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'webapp')));
app.use('/admin', express.static(path.join(__dirname, 'admin')));

const BOT_TOKEN = process.env.BOT_TOKEN || "";
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || "adminpass";
const HMAC_SECRET = process.env.HMAC_SECRET || "change_me";
if (!BOT_TOKEN) console.warn("BOT_TOKEN not set!");

const bot = new Telegraf(BOT_TOKEN);

// SQLite DB
const dbFile = path.join(__dirname, 'db', 'casino.db');
const db = new sqlite3.Database(dbFile);
db.serialize(() => {
  db.run(`CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY,
    balance INTEGER DEFAULT 1000,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
  )`);
  db.run(`CREATE TABLE IF NOT EXISTS rounds (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    round_id TEXT,
    user_id INTEGER,
    game TEXT,
    bet INTEGER,
    payout INTEGER,
    reels TEXT,
    server_seed TEXT,
    server_seed_hash TEXT,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
  )`);
});

// Bot commands
bot.start((ctx) => {
  const openBtn = {
    text: "Играть 🎰",
    web_app: { url: process.env.WEBAPP_BASE_URL ? process.env.WEBAPP_BASE_URL + '/index.html' : 'https://t.me/' + ctx.me + '?start' }
  };
  ctx.reply('Добро пожаловать в Nekit Casino (playmoney).', {
    reply_markup: { inline_keyboard: [[openBtn]] }
  });
});
bot.command('balance', async (ctx) => {
  const id = ctx.from.id;
  db.get('SELECT balance FROM users WHERE id=?', [id], (err,row) => {
    if (err) { ctx.reply('Ошибка'); return; }
    if (!row) {
      db.run('INSERT INTO users(id,balance) VALUES(?,?)', [id,1000]);
      ctx.reply('Баланс: 1000 (новый аккаунт)');
    } else {
      ctx.reply('Баланс: ' + row.balance);
    }
  });
});
bot.launch().then(()=>console.log('Bot started')).catch(e=>console.error(e));

// Helpers
function sha256(x){ return crypto.createHash('sha256').update(x).digest('hex'); }
function rngFromSeeds(serverSeed, clientSeed, counter){
  const h = crypto.createHmac('sha256', serverSeed).update(clientSeed + ':' + counter).digest();
  const val = h.readUInt32BE(0);
  return val / 0xFFFFFFFF;
}

// API: ensure user exists
function ensureUser(userId, cb){
  db.get('SELECT * FROM users WHERE id=?',[userId], (err,row)=>{
    if (err) return cb(err);
    if (!row) {
      db.run('INSERT INTO users(id,balance) VALUES(?,?)',[userId,1000], function(err2){
        if (err2) return cb(err2);
        return cb(null, {id:userId, balance:1000});
      });
    } else cb(null, row);
  });
}

// Spin slot
app.post('/api/slot/spin', (req,res)=>{
  try {
    const { userId, bet, clientSeed } = req.body;
    if (!userId || !bet) return res.status(400).json({error:'userId and bet required'});
    ensureUser(userId, (err,user)=>{
      if (err) return res.status(500).json({error:'db'});
      if (user.balance < bet) return res.status(400).json({error:'insufficient'});
      // deduct
      db.run('UPDATE users SET balance = balance - ? WHERE id=?',[bet,userId]);
      const serverSeed = crypto.randomBytes(32).toString('hex');
      const serverSeedHash = sha256(serverSeed);
      // 3 reels, 6 symbols
      const reels = [];
      for (let r=0;r<3;r++){
        const v = Math.floor(rngFromSeeds(serverSeed, clientSeed||'', r) * 6);
        reels.push(v);
      }
      // paytable similar to Pragmatic-style: three of kind with multipliers
      const paytable = {0:50,1:30,2:20,3:10,4:5,5:3};
      let multiplier = 0;
      if (reels[0]===reels[1] && reels[1]===reels[2]) multiplier = paytable[reels[0]] || 0;
      const payout = Math.floor(bet * multiplier);
      // credit payout
      db.run('UPDATE users SET balance = balance + ? WHERE id=?',[payout,userId]);
      const roundId = crypto.randomBytes(8).toString('hex');
      db.run(`INSERT INTO rounds(round_id,user_id,game,bet,payout,reels,server_seed,server_seed_hash)
             VALUES(?,?,?,?,?,?,?,?)`,[roundId,userId,'slot',bet,payout,JSON.stringify(reels),serverSeed,serverSeedHash]);
      // return result (commit only - serverSeedHash included; reveal via /api/reveal)
      db.get('SELECT balance FROM users WHERE id=?',[userId], (er, r2)=>{
        res.json({ok:true, roundId, result:{reels, payout, balance: r2.balance}, serverSeedHash});
      });
    });
  } catch(e){
    console.error(e); res.status(500).json({error:'internal'});
  }
});

// Dice game
app.post('/api/dice/roll', (req,res)=>{
  try {
    const { userId, bet, choice } = req.body; // choice: 1..6
    if (!userId || !bet || !choice) return res.status(400).json({error:'userId,bet,choice required'});
    ensureUser(userId, (err,user)=>{
      if (err) return res.status(500).json({error:'db'});
      if (user.balance < bet) return res.status(400).json({error:'insufficient'});
      db.run('UPDATE users SET balance = balance - ? WHERE id=?',[bet,userId]);
      const roll = Math.floor(Math.random()*6)+1;
      let payout = 0;
      if (roll === Number(choice)) payout = bet * 5; // 5x for exact hit
      db.run('UPDATE users SET balance = balance + ? WHERE id=?',[payout,userId]);
      const roundId = crypto.randomBytes(8).toString('hex');
      db.run(`INSERT INTO rounds(round_id,user_id,game,bet,payout,reels,server_seed,server_seed_hash)
             VALUES(?,?,?,?,?,?,?,?)`,[roundId,userId,'dice',bet,payout,JSON.stringify([roll]),'', '']);
      db.get('SELECT balance FROM users WHERE id=?',[userId], (er, r2)=>{
        res.json({ok:true, roundId, result:{roll, payout, balance: r2.balance}});
      });
    });
  } catch(e){ console.error(e); res.status(500).json({error:'internal'}); }
});

// Balance endpoint
app.get('/api/balance/:userId', (req,res)=>{
  const userId = req.params.userId;
  db.get('SELECT balance FROM users WHERE id=?',[userId],(err,row)=>{
    if (err) return res.status(500).json({error:'db'});
    if (!row) return res.json({balance:0});
    res.json({balance:row.balance});
  });
});

// Reveal endpoint
app.get('/api/reveal/:roundId', (req,res)=>{
  const rid = req.params.roundId;
  db.get('SELECT server_seed, server_seed_hash, reels, user_id FROM rounds WHERE round_id=?',[rid], (err,row)=>{
    if (err || !row) return res.status(404).json({error:'not found'});
    res.json({roundId: rid, serverSeed: row.server_seed, serverSeedHash: row.server_seed_hash, reels: JSON.parse(row.reels), userId: row.user_id});
  });
});

// Admin API (simple password)
app.get('/api/admin/rounds', (req,res)=>{
  const pass = req.query.pw || '';
  if (pass !== ADMIN_PASSWORD) return res.status(401).json({error:'unauthorized'});
  db.all('SELECT * FROM rounds ORDER BY id DESC LIMIT 200',[],(err,rows)=>{ if(err) return res.status(500).json({error:'db'}); res.json({rows}); });
});

app.get('/api/health', (_,res)=>res.json({ok:true}));

const PORT = process.env.PORT || 3000;
app.listen(PORT, ()=>console.log('Server running on',PORT));
